﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class PoisonPlayerBullet : PlayerBullet
{

    public PoisonPlayerBullet(float pVx, float pVy) : base(pVx, pVy, "sprite_poisonPlayerProjectile.png")
    {

    }


}