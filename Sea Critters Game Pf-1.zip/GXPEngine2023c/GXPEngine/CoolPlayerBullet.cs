﻿using GXPEngine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class CoolPlayerBullet : PlayerBullet
{
    public CoolPlayerBullet(float pVx, float pVy) : base(pVx, pVy, "sprite_icePlayerProjectile.png")
    {

    }


}