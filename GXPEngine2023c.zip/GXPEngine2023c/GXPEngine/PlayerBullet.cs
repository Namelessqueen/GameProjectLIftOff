﻿using GXPEngine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using TiledMapParser;

class PlayerBullet : AnimationSprite
{
    float vx, vy;
    Level level;
    public PlayerBullet(float pVx, float pVy, string filename = "circle.png", int cols = 1, int rows = 1) : base(filename, cols, rows)
    {
        SetOrigin(width/2, height/2);
        scale = 0.6f;
        vx = pVx;
        vy = pVy;
        level = game.FindObjectOfType<Level>();
    }

    protected virtual void Update()
    {
        if (((MyGame)game).isPaused) return;
        x += vx;
        y += vy;
        // TODO: Check whether offscreen / hit test, and then remove!
        // Destroy if off screen
        if (x < -level.x || x > -level.x + game.width ||
            y < -level.y || y > -level.y + game.height)
        {
            Console.WriteLine("Enemy bullet despawned");
            LateDestroy();
        }
    }
}

// SECONDARY BULLET CLASS

class PlayerSecondary : PlayerBullet
{
    int oldHeight = 0;
    int slider;
    private Player player;
    private List<AnimationCircles> Circles = new List<AnimationCircles>();

    public PlayerSecondary(float pVx, float pVy, int pSlider, string filename = "circle.png", int cols = 1, int rows = 1) : base(pVx, pVy, filename, cols, rows)
    {
        oldHeight = height;
        height = 5;
        alpha = 0.5f;
        player = game.FindObjectOfType<Player>();
        rotation = player.rotation;
        slider = pSlider;

        for (int i = 0; i < 10; i++)
        {
            Circles.Add(new AnimationCircles("circle.png", 1, 1));
            LateAddChild(Circles.Last());
            Circles.Last().SetOrigin(width / 2, height / 2);
            Circles.Last().width = 50;
            //Console.WriteLine("Circle generated");
        }
    }

    protected override void Update()
    {
        if (((MyGame)game).isPaused) return;
        base.Update();

        width += 2;
        for (int i = 0; i < 10; i++)
        {
            AnimationCircles circle = Circles[i];
            circle.width = 50;
            circle.height = height * oldHeight / width;
            //Console.WriteLine("Circle generated");
        }

        if (DistanceTo(player) > slider*3)
        {
            Destroy();
        }
    }
}



class AnimationCircles : AnimationSprite
{
    public AnimationCircles(string filename = "circle.png", int cols = 1, int rows = 1) : base(filename, cols, rows)
    {
        
    }

    void Update()
    {
        //width /= 2;
       // height = width;
    }
}